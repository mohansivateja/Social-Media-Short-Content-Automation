import requests

API_URL = "http://127.0.0.1:8000"

def upload_video(filepath, endpoint):
    with open(filepath, "rb") as f:
        files = {"file": f}
        response = requests.post(f"{API_URL}/{endpoint}/", files=files)
        print(response.json())

if __name__ == "__main__":
    video_file = "sample.mp4"

    print("Generating clip...")
    upload_video(video_file, "generate_clips")

    print("Generating thumbnail...")
    upload_video(video_file, "generate_thumbnail")

    print("Generating captions...")
    upload_video(video_file, "generate_captions")
