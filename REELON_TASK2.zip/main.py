from fastapi import FastAPI, UploadFile, File
import whisper
import openai
import os
import ffmpeg

app = FastAPI()

# Load Whisper Model
whisper_model = whisper.load_model("small")

# OpenAI API Key (Set this as an environment variable)
OPENAI_API_KEY = os.getenv("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")

@app.post("/generate_clips/")
async def generate_clips(file: UploadFile = File(...), start_time: int = 0, duration: int = 10):
    """Extracts a short clip from a video file."""
    video_path = f"temp_{file.filename}"
    output_path = f"clip_{file.filename}"
    
    with open(video_path, "wb") as f:
        f.write(file.file.read())

    # Use FFmpeg to extract the clip
    ffmpeg.input(video_path, ss=start_time, t=duration).output(output_path).run(overwrite_output=True)
    
    return {"message": "Clip generated", "output_file": output_path}

@app.post("/generate_thumbnail/")
async def generate_thumbnail(file: UploadFile = File(...), timestamp: int = 5):
    """Extracts a thumbnail from the video."""
    video_path = f"temp_{file.filename}"
    thumbnail_path = f"thumbnail_{file.filename}.jpg"
    
    with open(video_path, "wb") as f:
        f.write(file.file.read())

    # Use FFmpeg to extract a single frame as a thumbnail
    ffmpeg.input(video_path, ss=timestamp).output(thumbnail_path, vframes=1).run(overwrite_output=True)
    
    return {"message": "Thumbnail generated", "thumbnail": thumbnail_path}

@app.post("/generate_captions/")
async def generate_captions(file: UploadFile = File(...)):
    """Generates captions using Whisper AI and LLM."""
    video_path = f"temp_{file.filename}"
    
    with open(video_path, "wb") as f:
        f.write(file.file.read())

    # Transcribe video using Whisper
    result = whisper_model.transcribe(video_path)
    transcript = result["text"]

    # Use OpenAI GPT to generate an engaging caption
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "Generate an engaging social media caption based on this transcript:"},
            {"role": "user", "content": transcript}
        ],
    )
    
    caption = response["choices"][0]["message"]["content"]

    return {"message": "Caption generated", "transcript": transcript, "caption": caption}
